package oopsdemo3;

public class Demo {
 public int a=100;
 public void display() {
	 System.out.println("Hello from Public Method");
	 
 }
}
